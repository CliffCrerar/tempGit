<?php
namespace XFramework;

/**
 * Roundcube Plus Framework plugin.
 *
 * Copyright 2017, Tecorama LLC.
 *
 * @license Commercial. See the LICENSE file for details.
 */

class Utils
{
    /**
     * Converts an integer to a human-readeable file size string.
     *
     * @param int $size
     * @return string
     */
    static public function sizeToString($size)
    {
        if (!is_numeric($size)) {
            return "-";
        }

        $units = array("B", "kB", "MB", "GB", "TB", "PB");
        $index = 0;

        while ($size >= 1000) {
            $size /= 1000;
            $index++;
        }

        return $size . $units[$index];
    }

    /**
     * Shortens a string to the specified length and appends (...). If the string is shorter than the specified length,
     * the string will be left intact.
     *
     * @param string $string
     * @param int $length
     * @return string
     */
    public static function shortenString($string, $length = 50)
    {
        $string = trim($string);

        if (strlen($string) <= $length) {
            return $string;
        }

        $string = substr($string, 0, $length);

        if ($i = strrpos($string, " ")) {
            $string = substr($string, 0, $i);
        }

        return $string . "...";
    }

    /**
     * Returns a string containing a relative path for saving files based on the passed id. This is used for limiting
     * the amount of files stored in a single directory.
     *
     * @param int $id
     * @param int $idsPerDir
     * @param int $levels
     * @return string
     */
    public static function structuredDirectory($id, $idsPerDir = 500, $levels = 2)
    {
        if ($idsPerDir <= 0) {
            $idsPerDir = 100;
        }

        if ($levels < 1 || $levels > 3) {
            $levels = 2;
        }

        $level1 = floor($id / $idsPerDir);
        $level2 = floor($level1 / 1000);
        $level3 = floor($level2 / 1000);

        return ($levels > 2 ? sprintf("%03d", $level3 % 1000) . "/" : "") .
            ($levels > 1 ? sprintf("%03d", $level2 % 1000) . "/" : "") .
            sprintf("%03d", $level1 % 1000) . "/";
    }


    /**
     * Returns a string that is sure to be a valid file name.
     *
     * @param string $string
     * @return string
     */
    public static function ensureFileName($string)
    {
        $result = preg_replace("/[\/\\\:\?\*\+\%\|\"\<\>]/i", "_", strtolower($string));
        $result = trim(preg_replace("([\_]{2,})", "_", $result), "_ \t\n\r\0\x0B");
        return $result ? $result : "unknown";
    }

    /**
     * Returns a unique file name. This function generates a random name, then checks if the file with this name already
     * exists in the specified directory. If it does, it generates a new random file name.
     *
     * @param string $path
     * @param string $ext
     * @param string $prefix
     * @return string
     */
    public static function uniqueFileName($path, $ext = false, $prefix = false)
    {
        if (strlen($ext) && $ext[0] != ".") {
            $ext = "." . $ext;
        }

        $path = self::addSlash($path);

        do {
            $fileName = uniqid($prefix, true) . $ext;
        } while (file_exists($path . $fileName));

        return $fileName;
    }

    /**
     * Extracts the extension from file name.
     *
     * @param string $fileName
     * @return string
     */
    public static function ext($fileName)
    {
        return strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    }

    /**
     * Creates an empty directory with write permissions. It returns true if the directory already exists and is
     * writable. Also, if umask is set, mkdir won't create the directory with 0777 permissions, for exmple, if umask
     * is 0022, the outcome will be 0777-0022 = 0755, so we reset umask before creating the directory.
     *
     * @param string $dir
     * @return boolean
     */
	public static function makeDir($dir)
	{
		if (file_exists($dir)) {
            return is_writable($dir);
        }

		$umask = umask(0);
		$result = @mkdir($dir, 0777, true);
		umask($umask);

		return $result;
	}

    /**
     * Recursively removes a directory (including all the hidden files.)
     *
     * @param string $dir
     * @param bool $followLinks Should we follow directory links?
     * @param bool $contentsOnly Removes contents only leaving the directory itself intact.
     * @return boolean
     */
    public static function removeDir($dir, $followLinks = false, $contentsOnly = false)
    {
        if (empty($dir) || !is_dir($dir)) {
            return true;
        }

        $dir = self::addSlash($dir);
        $files = array_diff(scandir($dir), array(".", ".."));

        foreach ($files as $file) {
            if (is_link($dir . $file) && !$followLinks) {
                continue;
            } else if (is_dir($dir . $file)) {
                self::removeDir($dir . $file);
            } else {
                unlink($dir . $file);
            }
        }

        return $contentsOnly ? true : rmdir($dir);
    }

    /**
     * Returns the current url. Optionally it appends a path specified by the $path parameter.
     *
     * @param string $path
     * @return string|boolean
     */
	public static function getUrl($path = false, $hostOnly = false, $cut = false)
	{
        // if absolute path specified, simply return it
        if (strpos($path, "://")) {
            return $path;
        }

        // get the protocol, check for proxy
        if(empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
            $protocol = empty($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on" ? "http" : "https";
        } else {
            $protocol = $_SERVER['HTTP_X_FORWARDED_PROTO'];
        }

        if ($protocol != "http" && $protocol != "https") {
            $protocol = "http";
        }

        // if full url specified but without the protocol, prepend http or https and return.
        // we can't just leave it as is because roundcube will prepend the current domain
        if (strpos($path, "//") === 0) {
            return $protocol . ":" . $path;
        }

        // get the port, check for proxy
        if (empty($_SERVER['HTTP_X_FORWARDED_PORT'])) {
            $port = empty($_SERVER['SERVER_PORT']) ? 80 : $_SERVER['SERVER_PORT'];
        } else {
            $port = $_SERVER['HTTP_X_FORWARDED_PORT'];
        }

        if ($port != 443 && $port != 80) {
            $port = ":" . $port;
        } else {
            $port = "";
        }

        // get host, check for proxy
        if (empty($_SERVER['HTTP_X_FORWARDED_HOST'])) {
            $host = empty($_SERVER['SERVER_NAME']) ? false : $_SERVER['SERVER_NAME'];
        } else {
            $host = $_SERVER['HTTP_X_FORWARDED_HOST'];
        }

        if (empty($host)) {
            return false;
        }

        $url = parse_url($_SERVER['REQUEST_URI']);
        $urlPath = $url['path'];

        // in cpanel this will have index.php at the end
        if (substr($urlPath, -4) == ".php") {
            $urlPath = dirname($urlPath);
        }

        if (strpos($path, "/") === 0) {
            $path = substr($path, 1);
        }

        if ($hostOnly) {
            return $host;
        }

        $result = self::addSlash($protocol . "://" . $host . $port . $urlPath);

        // if paths to cut were specified, find and cut the resulting url
        if ($cut) {
            if (!is_array($cut)) {
                $cut = array($cut);
            }

            foreach ($cut as $val) {
                if (($pos = strpos($result, $val)) !== false) {
                    $result = substr($result, 0, $pos);
                }
            }
        }

        return $result . $path;
	}

    /**
     * Returns true if the program runs under cPanel.
     *
     * @return bool
     */
    public static function isCpanel()
    {
        return strpos(self::getUrl(), "/cpsess") !== false;
    }

    /**
     * Removes the slash from the end of a string.
     *
     * @param string $string
     * @return string
     */
	public static function removeSlash($string)
	{
		return substr($string, -1) == '/' || substr($string, -1) == '\\' ? substr($string, 0, -1) : $string;
	}

    /**
     * Adds a slash to the end of the string.
     *
     * @param string $string
     * @return string
     */
	public static function addSlash($string)
	{
		return substr($string, -1) == '/' || substr($string, -1) == '\\' ? $string : $string . '/';
	}

    /**
     * Converts a string representation of the boolean "true" or "false" into the actual boolean value.
     *
     * @param string $value
     * @return boolean
     */
    public static function strToBool($value)
    {
        switch ($value) {
            case "true":
                return true;
            case "false":
                return false;
            default:
                return $value;
        }
    }

    /**
     * Creates a random token composed of lower case letters and numbers.
     *
     * @param int $length
     * @return string
     */
    public static function randomToken($length = 32)
    {
        $characters = "abcdefghijklmnopqrstuvwxyz1234567890";
        $charactersLength = strlen($characters);
        $result = "";

        for ($i = 0; $i < $length; $i++) {
            $result .= $characters[mt_rand(0, $charactersLength - 1)];
        }

        return $result;
    }

    /**
     * Encodes an integer id using Roundcube's desk key and returns hex string.
     *
     * @param int $id
     * @return string
     */
    public static function encodeId($id, $rcmail = null)
    {
        if (!$rcmail) {
            $rcmail = \rcmail::get_instance();
        }

        return dechex(crc32($rcmail->config->get("des_key")) + $id);
    }

    /**
     * Decodes an id encoded using encodeId()
     *
     * @param string $encodedId
     * @return int
     */
    public static function decodeId($encodedId, $rcmail = null)
    {
        if (!$rcmail) {
            $rcmail = \rcmail::get_instance();
        }

        return hexdec($encodedId) - crc32($rcmail->config->get("des_key"));
    }

    /**
     * Creates a string that contains encrypted information about an action and its associated data. This function can
     * be used to create strings in the url that are masked from the users.
     *
     * @param string $action
     * @param string $data
     * @return string
     */
    public static function encodeUrlAction($action, $data, $rcmail = null)
    {
        if (!$rcmail) {
            $rcmail = \rcmail::get_instance();
        }

        $array = array("action" => $action, "data" => $data);

        return rtrim(strtr(base64_encode($rcmail->encrypt(json_encode($array), "des_key", false)), "+/", "-_"), "=");
    }

    /**
     * Decodes a string encoded with encodeUrlAction()
     *
     * @param string $encoded
     * @param string $data
     * @return string|boolean
     */
    public static function decodeUrlAction($encoded, &$data, $rcmail = null)
    {
        if (!$rcmail) {
            $rcmail = \rcmail::get_instance();
        }

        $array = json_decode($rcmail->decrypt(
            base64_decode(str_pad(strtr($encoded, "-_", "+/"), strlen($encoded) % 4, "=", STR_PAD_RIGHT)),
            "des_key",
            false
        ), true);

        if (is_array($array) && array_key_exists("action", $array) && array_key_exists("data", $array)) {
            $data = $array['data'];
            return $array['action'];
        }

        return false;
    }

    /**
     * Loads the specified config file and returns the array of config options.
     *
     * @param string $configFile
     * @return array
     */
    public static function loadConfigFile($configFile)
    {
        $config = [];

        if (file_exists($configFile)) {
            include($configFile);
        }

        return $config;
    }

    /**
     * Logs a message in a custom log file.
     *
     * @param string $text
     * @param string $file
     * @return bool|int
     */
    public static function xlog($text, $file = "xlog")
    {
        return file_put_contents(
            rtrim(RCUBE_INSTALL_PATH, "/") . "/logs/$file", date("[Y-m-d H:i:s] ") . $text . "\n",
            FILE_APPEND
        );
    }
}