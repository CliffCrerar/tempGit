<?php

return array(
    "colors" => array("6da1d3", "6dcfd3", "6dd374", "b76dd3", "d3bc6d","ce7070"),
    "default_color" => "6da1d3",
    "font_icons_toolbars" => false,
);